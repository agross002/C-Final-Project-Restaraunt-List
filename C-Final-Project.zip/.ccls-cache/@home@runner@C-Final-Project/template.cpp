
#include <iostream>
#include <string>
using namespace std;

int main() {

  char user_input;
  do {
    // print menu
    cout << "**************************************" << endl;
    cout << "*    Welcome the cat shelter app!    *" << endl;
    cout << "* Please chose  an option:           *" << endl;
    cout << "*   - l: list the available cats     *" << endl;
    cout << "*   - r: remove cat from family      *" << endl;
    cout << "*   - q: quit                        *" << endl;
    cout << "**************************************" << endl;
    // get user input
    cin >> user_input;

    // choose a branch depending on the input
    switch (user_input) {
    case 'l':
    case 'L':
      cout << "This is the list of available cats for adoption:" << endl;
      break;
    case 'r':
    case 'R':
      cout << "Which cat will be adopted?" << endl;
      break;
    case 'q':
    case 'Q':
      cout << "Bye!" << endl;
      break;
    default:
      cout << "Invalid choice. Please choose a character from the list" << endl;
      break;
    }

  } while (user_input != 'q' && user_input != 'Q');

  return 0;
}
